package com.example.myvoice;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.provider.CalendarContract;
import android.speech.RecognitionListener;
import android.speech.RecognitionService;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import java.util.Calendar;
import android.net.Uri;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextToSpeech MyText;
    private SpeechRecognizer mySpeechRecognizer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        VideoView videoView = findViewById(R.id.videoView);
        String videoPath = (("android.resource://" + getPackageName() + "/"+R.raw.video));
        Uri uri = Uri.parse(videoPath);
        videoView.setVideoURI(uri);
        videoView.start();

       /* MediaController mediaController = new MediaController(this);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);
*/
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setBackgroundColor(Color.parseColor("#FF0099CC"));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
                mySpeechRecognizer.startListening(intent);
            }
        });
        initializeTextToSpeech();
        initializeSpeechRecognizer();
    }
    private void processResult(String command){
        command = command.toLowerCase();

        if(command.indexOf("what is")!=-1) {
            if (command.indexOf("your name") != -1) {
                speak("my name is veronica");
            }
        }
        if(command.indexOf("who made")!=-1) {
             if (command.indexOf("you") != -1) {
                speak("design at lovely professional university");
            }
        }
        if(command.indexOf("what is")!=-1) {
            if (command.indexOf("my name") != -1) {
                speak("your name is vikas and you are my creator");
            }
        }
        if(command.indexOf("tell me")!=-1) {
            if (command.indexOf("a joke") != -1) {
                speak("jokes are over");
            }
        }
        if(command.indexOf("say hi to everyone")!=-1) {
            speak("hey everybody, my name is veronica. i am voice assistant");
        }
        if(command.indexOf("what is time now")!=-1) {
                Date now = new Date();
                String time = DateUtils.formatDateTime(this, now.getTime(),
                DateUtils.FORMAT_SHOW_TIME);
                speak("the time now is " + time);
        }
            if (command.indexOf("stop") != -1) {
                speak("sorry!! tap to talk again with veronica");
            }

        else{
        }
    }


    private void initializeSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)){
            mySpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            mySpeechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {

                }

                @Override
                public void onBeginningOfSpeech() {

                }

                @Override
                public void onRmsChanged(float rmsdB) {

                }

                @Override
                public void onBufferReceived(byte[] buffer) {

                }

                @Override
                public void onEndOfSpeech() {

                }

                @Override
                public void onError(int error) {

                }

                @Override
                public void onResults(Bundle bundle) {

                    List<String> results = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                    processResult(results.get(0));

                }

                @Override
                public void onPartialResults(Bundle partialResults) {

                }

                @Override
                public void onEvent(int eventType, Bundle params) {

                }
            });
        }
    }

    private void initializeTextToSpeech() {
        MyText = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(MyText.getEngines().size() == 0){
                    Toast.makeText(MainActivity.this, "This is no Text Engines on your device",Toast.LENGTH_LONG).show();
                    finish();
                }
                else {
                    MyText.setLanguage(Locale.US);
                    speak("hello! i am veronica , how can I help you! ");
                }

            }
        });
    }

    private void speak(String message) {
        if(Build.VERSION.SDK_INT>-21){
            MyText.speak(message,TextToSpeech.QUEUE_FLUSH,null,null);
        }
        else {
            MyText.speak(message,TextToSpeech.QUEUE_FLUSH,null);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPause() {
        super.onPause();
        MyText.shutdown();
    }
}
